using System;

namespace Domain.Entities
{
    public class Bill
    {
        // Every bill needs a unique ID
        public Guid Id { get; set; } = Guid.NewGuid();

        // Which client does this bill belong to?
        public Guid ClientId { get; set; }

        // Total kWh used (sum of all readings)
        public float TotalConsumption { get; set; }

        // How much per kWh? (we’ll use $0.12 for now)
        public decimal PricePerKwh { get; set; }

        // The final amount to pay
        public decimal TotalCost { get; set; }

        // When was this bill calculated?
        public DateTime CalculatedAt { get; set; }

        // Optional: time range for this bill
        public DateTime BillingPeriodStart { get; set; }
        public DateTime BillingPeriodEnd { get; set; }
    }
}
