using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Application.Interfaces;
using Application.Interfaces.Repositories;
using Domain.Entities;

namespace Application.Services.BillingService
{
    public class BillingService : IBillingService
    {
        private readonly IBillingRepository _billingRepository;
        private readonly IClientRepository _clientRepository;

        // Price per kWh - we’re using a fixed rate for now
        private const decimal PricePerKwh = 0.12m;

        public BillingService(
            IBillingRepository billingRepository,
            IClientRepository clientRepository)
        {
            _billingRepository = billingRepository;
            _clientRepository = clientRepository;
        }

        public async Task<Bill> CalculateBill(Guid clientId)
        {
            // Step 1: Get the client and their readings from the database
            var clients = await _clientRepository.GetAll();
            var client = clients.FirstOrDefault(c => c.Id == clientId);

            // If client doesn’t exist, throw an error
            if (client == null)
            {
                throw new Exception($"Client with ID {clientId} not found");
            }

            // Step 2: Calculate total consumption
            float totalConsumption = 0;
            DateTime? earliestReading = null;
            DateTime? latestReading = null;

            if (client.Readings != null && client.Readings.Any())
            {
                // Sum all the reading values
                totalConsumption = client.Readings.Sum(r => r.Value);

                // Find the date range
                earliestReading = client.Readings.Min(r => r.TimeStamp);
                latestReading = client.Readings.Max(r => r.TimeStamp);
            }

            // Step 3: Calculate the cost
            // Cost = consumption × price per kWh
            decimal totalCost = (decimal)totalConsumption * PricePerKwh;

            // Step 4: Create the bill object
            var bill = new Bill
            {
                ClientId = clientId,
                TotalConsumption = totalConsumption,
                PricePerKwh = PricePerKwh,
                TotalCost = totalCost,
                CalculatedAt = DateTime.UtcNow,
                BillingPeriodStart = earliestReading ?? DateTime.UtcNow,
                BillingPeriodEnd = latestReading ?? DateTime.UtcNow
            };

            // Step 5: Save the bill to the database
            await _billingRepository.AddBill(bill);

            // Step 6: Return the bill
            return bill;
        }

        public async Task<Bill?> GetBillForClient(Guid clientId)
        {
            return await _billingRepository.GetBillByClientId(clientId);
        }

        public async Task<IEnumerable<Bill>> GetAllBills()
        {
            return await _billingRepository.GetAllBills();
        }
    }
}
