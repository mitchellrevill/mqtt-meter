using Application.Interfaces.Repositories;
using Domain.Entities;
using Infrastructure.DatabaseContext;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Infrastructure.Repositories
{
    public class BillingRepository : IBillingRepository
    {
        private readonly MqttDbContext _context;

        // Constructor - this is how we get access to the database
        public BillingRepository(MqttDbContext context)
        {
            _context = context;
        }

        // Add a new bill to the database
        public async Task<Bill> AddBill(Bill bill)
        {
            // Add the bill to the DbSet
            _context.Bill.Add(bill);

            // Actually save it to the database
            await _context.SaveChangesAsync();

            // Return the bill (now with a saved ID)
            return bill;
        }

        // Find a bill for a specific client
        public async Task<Bill?> GetBillByClientId(Guid clientId)
        {
            // Look through all bills and find one matching this clientId
            // FirstOrDefaultAsync returns the first match, or null if none found
            return await _context.Bill
                .Where(b => b.ClientId == clientId)
                .OrderByDescending(b => b.CalculatedAt) // Get the most recent
                .FirstOrDefaultAsync();
        }

        // Get all bills (for testing/admin purposes)
        public async Task<IEnumerable<Bill>> GetAllBills()
        {
            // ToListAsync gets all bills and converts to a list
            return await _context.Bill.ToListAsync();
        }
    }
}
